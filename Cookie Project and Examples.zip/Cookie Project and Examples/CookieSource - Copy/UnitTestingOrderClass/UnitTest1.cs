﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Script.Serialization; //Added 
using CookieSource;
namespace UnitTestingOrderClass
{
    [TestClass]
    public class UnitTest1
    {
         Order TestGETSET = new Order();

        [TestMethod]
        public void TestOrderNumber()
        {

            int i = 66;
            TestGETSET.OrderNumber = i;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(i);
            String actual = js.Serialize(TestGETSET.OrderNumber);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void TestCustomerName()
        {

            String n = "name";
            TestGETSET.CustomerName = n;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(n);
            String actual = js.Serialize(TestGETSET.CustomerName);
            Assert.AreEqual(expected, actual);



        }

        [TestMethod]
        public void TestPhoneNumber()
        {

            int i = 11111111;
            TestGETSET.OrderNumber = i;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(i);
            String actual = js.Serialize(TestGETSET.OrderNumber);
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void TestCookieType()
        {

            Char C = 'C';
            TestGETSET.CookieType = C;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(C);
            String actual = js.Serialize(TestGETSET.CookieType);
            Assert.AreEqual(expected, actual);



        }

        [TestMethod]
        public void TestQuanity()
        {

            int q = 1;
            TestGETSET.Quanity = q;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(q);
            String actual = js.Serialize(TestGETSET.Quanity);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestOrderDate()
        {

            DateTime t = DateTime.Now;
            TestGETSET.OrderDate = t;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(t);
            String actual = js.Serialize(TestGETSET.OrderDate);
            Assert.AreEqual(expected, actual);



        }

        [TestMethod]
        public void TestDeliveryDate()
        {

            DateTime T = DateTime.Now;
            TestGETSET.DeliverDate = T;
            var js = new JavaScriptSerializer();
            String expected = js.Serialize(T);
            String actual = js.Serialize(TestGETSET.DeliverDate);
            Assert.AreEqual(expected, actual);



        }


    }


}
