﻿/*This is an example of composition
 One class contins an object of another class
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridViewWithBooksAndAuthors
{
    public class Author
    {
        public string AuthID { get; set; }

        public string AuthName { get; set; }

        public List<Book> AuthBooks { get; set; } //example of Compostion

        public double Total { get; set; }

        public Author(string id, string name)
        {
            AuthID = id;
            AuthName = name;
        }

        public Author(string id, string name, List<Book> b)
        {
            AuthID = id;
            AuthName = name;
            AuthBooks = b;
        }

        public double CalcTotal()
        {
            double total = (from books in AuthBooks
                            select books.Price).Sum();

            return total;

        }
    }

    public class Book
    {
        public string Title { get; set; }

        public int NumPages { get; set; }

        public double Price { get; set; }

        public Book(string title, int pages, double price)
        {
            Title = title;
            NumPages = pages;
            Price = price;
        }
    }
}
