﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CookieSource //add Icompariable 
{
    [Serializable]
    public class Order: IComparable<Order>
    {
        #region VARIABLES

        private int orderNumber;
        private string customerName;
        private long phoneNumber;
        private char cookieType;
        private int quanity;
        private DateTime orderDate;
        private DateTime deliveryDate;


        #endregion VARIABLES

        #region Order Number 

        public int OrderNumber
        {
            get
            {
                return orderNumber;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (value > 0)//Trims the string and makes sure it's not NULL,nothing 
                {
                    this.orderNumber = value;
                }

            }
        }
        #endregion
        #region Customer Name 
        public string CustomerName
        {
            get
            {
                return customerName;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (value.Trim().Length > 0)//Trims the string and makes sure it's not NULL,nothing 
                {
                    customerName = value;//--value key word is default to send data
                }
                else
                {

                }
            }
        }
        #endregion
        #region Phone Number 
        public long PhoneNumber
        {
            get
            {
                return phoneNumber;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (value > 0)//Trims the string and makes sure it's not NULL,nothing 
                {
                    this.phoneNumber = value;
                }

            }
        }
        #endregion
        #region Cookie Type 
        public char CookieType
        {
            get
            {
                return cookieType;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (char.ToUpper(value) == 'O' ||
                    char.ToUpper(value) == 'C' ||
                    char.ToUpper(value) == 'S')
                {
                    cookieType = value;//--value key word is default to send data
                }
                else
                {
                    // TODO: Throw EXCEPTION Here 
                }
            }
        }
        #endregion
        #region Quanity 
        public int Quanity
        {
            get
            {
                return quanity;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (value > 11)//Trims the string and makes sure it's not NULL,nothing 
                {
                    this.quanity = value;
                } else
                {

                }

            }
        }
        #endregion
        #region Order Date
        public DateTime OrderDate
        {
            get
            {
                return orderDate;
            } // A Getter return of the private data element(returns data) 
            set
            {
                
                
                    this.orderDate = value;
                

            }
        }
        #endregion
        #region Delivery Date
        public DateTime DeliverDate
        {
            get
            {
                return deliveryDate;
            } // A Getter return of the private data element(returns data) 
            set
            {
                //Validation
                if (orderDate >= deliveryDate)//Trims the string and makes sure it's not NULL,nothing 
                {
                    this.deliveryDate = value;
                }
                else {
                    Console.WriteLine("Logic doesn't exist");
                }

            }
        }
        #endregion

        #region DEFAULT CONSTRUCTOR 
        public Order()
        {

            OrderNumber = 1;
            CustomerName = "Ethan";
            PhoneNumber = 11111;
            CookieType = 'C';
            Quanity = 1;
            OrderDate =DateTime.Now ;
            deliveryDate = DateTime.Now;

        }

        #endregion
        #region EXCEPTIONS ALL CONSTRUCTOR
        public Order(int number, string name , int phone, char type,int quanity,DateTime orderdate, DateTime deliverydate )
        {
           
            OrderNumber = number;  
            CustomerName = name; 
            PhoneNumber = phone;
            CookieType = type;
            Quanity = quanity;
            OrderDate = orderdate;
            DeliverDate = deliverydate;

        }
        #endregion


        #region iCompareable 

        #endregion


        public override string ToString()
        {
            return "Order Number: "   + this.orderNumber  + " " + 
                   "Customer Name:  " + this.customerName + " " + 
                   "Phone Number: "   + this.phoneNumber  + " " +
                   "Cookie Type: "    + this.cookieType   + " " + 
                   "Quantity: "    + this.quanity      + " " +
                   "Order Date: "     + this.orderDate    + " " +
                   "Delivery Date: " + this.deliveryDate;
                   
                  
        }


        public int CompareTo(Order s)
        {
            //OPTION 2: Descending Order 

            return this.DeliverDate.CompareTo(((Order)s).DeliverDate);
            //or use Ascendering Order: 

            // return ((Order)s).DeliveryDate.CompareTo(this.DeliveryDate);
        }
    }
}
