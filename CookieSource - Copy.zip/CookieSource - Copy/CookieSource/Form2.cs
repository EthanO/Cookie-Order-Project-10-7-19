﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace CookieSource
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        private void ValidateNumber(Order order)
        {
            try
            {
                order.PhoneNumber = Int64.Parse(textBox2.Text);
            }
            catch (Exception ex)
            {
                string holder = textBox2.Text;
                if (textBox2.Text == "") holder = "Empty";
                throw new CookieException(holder);
            }
            // throw new CookieException(order.PhoneNumber.ToString());

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Order order = new Order();
            order.CustomerName = textBox1.Text;
           if (order.CustomerName == "Ethan") { 
                order.CustomerName = textBox1.Text;
                label6.Text = "Make sure you're entering the customers name correctly";
                return;
            }
            try
            {
                ValidateNumber(order);
            }
            catch (CookieException ex)
            { 
                label6.Text = ex.Message;
                return;
            }
            char character;
            try
            {
               character = char.Parse(textBox3.Text.ToUpper());
                if(character == 'C' || character == 'O' || character == 'S')
                {
                    
                } else
                {
                    label6.Text = "Make sure you're entering the customers cookie type correctly";
                    return;
                }
            }
            catch (Exception ex)
            {
                label6.Text = "Make sure you're entering the customers cookie type correctly";
                return;
            }
            order.CookieType = character;
            try
            {
                order.Quanity = Convert.ToInt32(textBox4.Text);
                if(order.Quanity < 12)
                {
                    //throw new CookieException(string.Format("Order quantity must be at least ", 12));
                    label6.Text = "Order quantity must be at least a dozen";
                    return;
                }
            }
            catch (Exception ex)
            {
                label6.Text = "Make sure you're entering the customers quantity correctly";
                return;
            }
            order.OrderDate = DateTime.Now;
            order.DeliverDate = dateTimePicker1.Value;
            if(order.DeliverDate < order.OrderDate)
            {
                label6.Text = "Make sure delivery date is after current date";
                return;
            }
            MessageBox.Show("Order has successfully been submitted.");
            label6.Text = "";
            Form1.orderList.Add(order);
            order.OrderNumber = 1;
            try
            {
                FileStream outFile = new FileStream("Data.ser",
                     FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                foreach (var item in Form1.orderList)
                {
                    if(item.OrderNumber >= order.OrderNumber)
                    {
                        order.OrderNumber += 1;
                    }
                }
                order.OrderNumber = order.OrderNumber - 1;
                foreach (var item in Form1.orderList)
                {
                    bf.Serialize(outFile, item);
                }
                Form1.orderList.Clear();
                outFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing list to file " + ex.Message);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();//Hide cirrent form.
            f1.ShowDialog();//Display the next form window
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
    }

