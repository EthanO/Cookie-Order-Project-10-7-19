﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CookieSource
{
    public partial class Form1 : Form
    {
        public static List<Order> orderList = new List<Order>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //listBox1.Items.Clear();
            orderList.Clear();
            try
            {
                if (File.Exists("Data.ser"))
                {
                    FileStream inFile = new FileStream("Data.ser",
                        FileMode.Open, FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    //copy invoices from the file to the invoiceList
                    while (inFile.Position < inFile.Length)
                    {
                        /* use this logic if only a single object type is in the file                        
                        Book book = (Book)bFormatter.Deserialize(inFile);
                        Form1.bookList.Add(book);                        
                        */
                        //use this logic if multiple object types are in the file
                        object obj = bFormatter.Deserialize(inFile);
                        if (obj.GetType() == typeof(Order))
                        {
                            orderList.Add((Order)obj);
                        }
                        else
                        {
                            //additional logic if other types of objects are involved
                        }
                    }
                    inFile.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening file, program terminating" + ex.Message);
            }
            List<Order> sortedOrders = new List<Order>(orderList);
            sortedOrders.Sort();
            dataGridView1.DataSource = sortedOrders;
           //listBox1.DataSource = sortedBooks;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                FileStream outFile = new FileStream("Data.ser",
                     FileMode.Create, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                foreach (var item in Form1.orderList)
                {
                    bf.Serialize(outFile, item);
                }
                outFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing list to file " + ex.Message);
            }

            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Hide();
            f2.ShowDialog(); // Shows Form2
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
