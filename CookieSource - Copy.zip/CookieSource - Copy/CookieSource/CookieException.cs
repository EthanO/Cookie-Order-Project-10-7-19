﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CookieSource
{
    class CookieException : Exception
    {
        public CookieException(string number)
   : base(String.Format("Invalid phone number: {0}", number))
        {
            if (number == null) number = "Empty";
        }
    }
}