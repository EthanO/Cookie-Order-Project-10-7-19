﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace EnterInvoices
{
    public partial class EntryForm : Form
    {  
        public EntryForm()
        {
            InitializeComponent();
        }
        private void enterButton_Click(object sender, EventArgs e)
        {
            try
            {
                //create an invoice object
                InvoiceClass invoice = new InvoiceClass();
                //establish the object's properties
                invoice.InvoiceNum = Convert.ToInt32(txtInvoice.Text);
                invoice.Name = txtName.Text;
                invoice.Amount = Convert.ToDouble(txtAmount.Text);
                //add object to invoiceList
                MenuForm.invoiceList.Add(invoice);

                txtInvoice.Clear();
                txtName.Clear();
                txtAmount.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Error writing to file, check data", "Entry Error");
            }
        }
    }
}
