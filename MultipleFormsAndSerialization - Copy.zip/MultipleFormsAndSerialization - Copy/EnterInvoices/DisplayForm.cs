﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace EnterInvoices
{
    public partial class DisplayForm : Form
    {
        public static int invIndex = 0;

        public DisplayForm()
        {
            InitializeComponent();
            try
            {
                //get invoice from the list and display on form
                txtInvoice.Text = MenuForm.invoiceList[0].InvoiceNum.ToString();
                txtName.Text = MenuForm.invoiceList[0].Name;
                txtAmount.Text = MenuForm.invoiceList[0].Amount.ToString();
                btnFirst.Enabled = false;
                btnPrev.Enabled = false;
            }
            catch (NullReferenceException)
            {
                lblInstructions.Text = "You have viewed\nall the records";
                btnFirst.Enabled = false;
            }

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            InvoiceClass inv = new InvoiceClass();
            inv = MenuForm.invoiceList.First();

            //get first invoice from the list and display on form
            txtInvoice.Text = inv.InvoiceNum.ToString();
            txtName.Text = inv.Name;
            txtAmount.Text = inv.Amount.ToString();
            btnPrev.Enabled = false;
            btnNext.Enabled = true;
            btnFirst.Enabled = false;
            btnLast.Enabled = true;
            invIndex = 0;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            InvoiceClass inv = new InvoiceClass();
            inv = MenuForm.invoiceList.Last();

            //get last invoice from the list and display on form
            txtInvoice.Text = inv.InvoiceNum.ToString();
            txtName.Text = inv.Name;
            txtAmount.Text = inv.Amount.ToString();
            invIndex = MenuForm.invoiceList.Count - 1;            
            btnNext.Enabled = false;
            btnPrev.Enabled = true;
            btnLast.Enabled = false;
            btnFirst.Enabled = true;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            //get next invoice from the list and display on form
            invIndex -= 1;

            if (invIndex >= 0)
            {
                txtInvoice.Text = MenuForm.invoiceList[invIndex].InvoiceNum.ToString();
                txtName.Text = MenuForm.invoiceList[invIndex].Name;
                txtAmount.Text = MenuForm.invoiceList[invIndex].Amount.ToString();
                btnNext.Enabled = true;
                btnLast.Enabled = true;
                if (invIndex == 0)
	            {                  
                    btnPrev.Enabled = false;
                    btnFirst.Enabled = false;
	            }
            }
     
        }

        private void btnNext_Click(object sender, EventArgs e)
        {         
            //get next invoice from the list and display on form
            invIndex += 1;

            if (invIndex <= MenuForm.invoiceList.Count - 1)
            {
                txtInvoice.Text = MenuForm.invoiceList[invIndex].InvoiceNum.ToString();
                txtName.Text = MenuForm.invoiceList[invIndex].Name;
                txtAmount.Text = MenuForm.invoiceList[invIndex].Amount.ToString();
                btnPrev.Enabled = true;
                btnFirst.Enabled = true;
                if (invIndex == MenuForm.invoiceList.Count - 1)
                {
                    invIndex = MenuForm.invoiceList.Count - 1;                    
                    btnNext.Enabled = false;
                    btnLast.Enabled = false;
                }
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                MenuForm.invoiceList[invIndex].InvoiceNum = Convert.ToInt32(txtInvoice.Text);
                MenuForm.invoiceList[invIndex].Name = txtName.Text;
                MenuForm.invoiceList[invIndex].Amount = Convert.ToDouble(txtAmount.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error in data, please re-enter", "Update Record");
            }
            
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record",
                MessageBoxButtons.YesNo,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                try
                {                   
                    MenuForm.invoiceList.RemoveAt(invIndex);
                    MessageBox.Show("Record has been deleted", "Delete Record");
                    InvoiceClass inv = new InvoiceClass();
                    try
                    {
                        //get first invoice from the list and display on form
                        inv = MenuForm.invoiceList.First();                        
                        txtInvoice.Text = inv.InvoiceNum.ToString();
                        txtName.Text = inv.Name;
                        txtAmount.Text = inv.Amount.ToString();
                        btnPrev.Enabled = false;
                        btnNext.Enabled = true;
                        btnFirst.Enabled = false;
                        btnLast.Enabled = true;
                        invIndex = 0;
                    }
                    catch (Exception)
                    {
                        txtInvoice.Clear();
                        txtName.Clear();
                        txtAmount.Clear();
                        txtInvoice.Focus();
                    }
                   

                    

                }
                catch (Exception)
                {
                    MessageBox.Show("Error while deleting record", "Delete Record");
                }
            }
            else
            {
                MessageBox.Show("Record not deleted", "Delete Record");
            }
            
            
        }

    }
}
