﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;


namespace EnterInvoices
{
    public partial class MenuForm : Form
    {
        public static List<InvoiceClass> invoiceList = new List<InvoiceClass>();

        public MenuForm()
        {
            const string FILENAME = @"Invoices.ser";
            try
            {
                FileStream inFile = new FileStream(FILENAME,
                FileMode.Open, FileAccess.Read);
                BinaryFormatter bFormatter = new BinaryFormatter();
                object obj;

                //copy invoices from the file to the invoiceList
                while (inFile.Position < inFile.Length)
                {
                    obj = bFormatter.Deserialize(inFile);
                    invoiceList.Add((InvoiceClass)obj);
                }
            }
            catch (Exception)
            {
               
            }
            
            
            InitializeComponent();

            

        }
        private void btnEntry_Click(object sender, EventArgs e)
        {
            EntryForm entryForm = new EntryForm();
            entryForm.Show();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (invoiceList.Count > 0)
            {
                DisplayForm displayForm = new DisplayForm();
                displayForm.Show();
            }
            else
            {
                MessageBox.Show("There are no records to display", "Display Records");
            }
            
        }
       

    }
}
